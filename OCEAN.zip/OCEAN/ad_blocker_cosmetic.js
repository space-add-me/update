console.log("OCEAN Cosmetic Ad Blocker: Script Injected (v8 - Final Cleanup).");

/**
 * This function handles the removal of all unwanted elements,
 * including the final empty placeholder boxes.
 */
function removeAllUnwantedElements() {
    // --- Rule for the main IRCTC page ---
    const mainPageSelectors = [
        'app-ads',
        'app-banner',
        '.ads-container',
        'img[src*="cdn.jsdelivr.net/gh/corover/assets"]',
        'a[href*="corover.ai"]',
        'div[id^="div-gpt-ad-"]',
        '#disha-image',
        'img[src*="adgebra.net"]',
        '#chatbot',
        '#disha-placeholder-card', // **NEW: AskDISHA ka bacha hua placeholder box**
        '#splash-scrollable'     // **NEW: Uske andar ka scrollable box**
    ];

    // --- Rule for the AskDISHA iframe itself ---
    if (window.location.hostname.includes('askdisha.irctc.co.in')) {
        const chatbotRoot = document.getElementById('root');
        if (chatbotRoot && chatbotRoot.isConnected) {
            console.log("OCEAN Blocker: Removing entire chatbot root (#root) inside its iframe.");
            chatbotRoot.remove();
            return;
        }
    }

    // --- Run standard removal on the main page ---
    mainPageSelectors.forEach(selector => {
        try {
            document.querySelectorAll(selector).forEach(element => {
                if (element && element.isConnected) {
                    console.log(`OCEAN Blocker: Removing element -> ${selector}`);
                    element.remove();
                }
            });
        } catch (e) {
            console.error(`OCEAN Blocker: Error with selector "${selector}":`, e);
        }
    });
}

/**
 * Sets up a MutationObserver to watch for dynamic changes and re-apply our rules.
 */
function initializeDefinitiveFilter() {
    // Run the removal function once on initial load
    removeAllUnwantedElements();

    // Create an observer to watch for changes in the DOM
    const observer = new MutationObserver((mutations) => {
        removeAllUnwantedElements();
    });

    // Start observing the entire document for added nodes
    observer.observe(document.documentElement, {
        childList: true,
        subtree: true
    });
}

// Start the filter as soon as the script runs
initializeDefinitiveFilter();